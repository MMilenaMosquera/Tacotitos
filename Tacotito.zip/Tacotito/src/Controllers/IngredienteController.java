package Controllers;
import DAO.tipoIngredienteDao;
import DAO.ingredienteDao;
import Model.Ingrediente;
import java.sql.SQLException;
import Model.TipoIngrediente;
import java.sql.Connection;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

   
public class IngredienteController {
    private ingredienteDao ingDao;
    private tipoIngredienteDao TipoIngDao;
    static IngredienteController instance;
    
    
    public IngredienteController() throws SQLException {
     this.TipoIngDao = tipoIngredienteDao.getInstance();   
     this.ingDao = ingredienteDao.getInstance();
    
    }
    
    
    public static IngredienteController getInstance() throws SQLException{
        if(instance ==null){
            instance=new IngredienteController();
        }
        return instance;
       
    }
 
    public void guardarTipoIngrediente(String detalle, int cantMaxima) throws SQLException{
        TipoIngrediente ting = new TipoIngrediente(detalle, cantMaxima);
        this.TipoIngDao.guardarTipoIngrediente(ting);
        //System.out.println(ting);
    }
    
    /**
     *
     * @param Detalle
     * @param CantidadMax
     * @throws SQLException
     * @throws SQLException
     */
    public void nuevoTipoIngrediente(String Detalle, int CantidadMax) throws SQLException, SQLException{
        TipoIngrediente tip = null;
        this.TipoIngDao.guardarTipoIngrediente(tip);
    }    
     
      public void modificarTipoIngrediente(String detalle, int cantMax, int id) throws Exception {
        TipoIngrediente ting  = TipoIngDao.BuscarxId(id);
        if (ting == null) {
            System.out.println("NO el tipo de ingrediente");
        } else {
           ting.setDetalle(detalle);
           ting.setCantidadMax(cantMax);
           
            try {
                this.TipoIngDao.modificar(ting);
            } catch (SQLException ex) {
                Logger.getLogger(IngredienteController.class.getName()).log(Level.SEVERE, null, ex);
                throw ex;
            }
        }
    }
        
    public List<TipoIngrediente> listarTipoIngrediente() {
         
        return this.TipoIngDao.listarTipoIngrediente() ;
    }
    
    public TipoIngrediente buscarTipoIngredientePorId(int id) throws SQLException {
        return this.TipoIngDao.BuscarxId(id);
    }
     
    public void eliminarTipoIngrediente(int id) throws Exception {
        TipoIngrediente ting = this.TipoIngDao.BuscarxId(id);
        if (ting == null) {
            throw new Exception("Tipo Ingrediente No encontrado");
        } else {
            this.TipoIngDao.borrar(ting);
        }
    }
     
     
   /*--------------------------------- Controladora para el IngredienteDao ------------------------------------------  */
     
     public void guardarIngrediente(String nombreIngrediente, int precio, int idTipoIngrediente) throws SQLException{
        Ingrediente i = new Ingrediente(nombreIngrediente, precio);
        this.ingDao.guardarIngrediente(i);
        System.out.println(i);
    }
    
    public void nuevoTipoIngrediente(String nombreIngrediente, int precio, int idTipoIngrediente) throws SQLException {
        Ingrediente i = null;
        this.ingDao.guardarIngrediente(i);
    }    

     //public List<Ingrediente> listarIngredientes() {
         
       // return this.ingDao.listarIngredientes();
   // }

   
    
    
}   
       
    
    /*
    public void nuevoIngrediente(String nombre, int precio, TipoIngrediente tipoIngrediente) throws SQLException{
        Ingrediente i = new Ingrediente(nombre, precio, tipoIngrediente);
        ingredienteDao ing =ingredienteDao.getInstance();
        ing.nuevoIngrediente(i);
         
    }
    
    public void modificarIngrediente(String nombre, int precio, TipoIngrediente tipoIngrediente){
        
    }
    
    public void eliminarIngrediente(String nombre, int precio, TipoIngrediente tipoIngrediente){
        
    }
    
    public void guardarIngrediente(String nombre, int precio, TipoIngrediente tipoIngrediente){
        ingredienteDao ing;
        try {
            ing = ingredienteDao.getInstance();
        } catch (SQLException ex) {
            Logger.getLogger(IngredienteController.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    
}
*/