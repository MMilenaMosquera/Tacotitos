
package tacotito;

import java.sql.SQLException;
import View.VentanaInicio;


public class Programa {

   
    public static void main(String[] args) throws SQLException, Exception {
       VentanaInicio vntInico = new VentanaInicio();
       vntInico.setVisible(true);
       vntInico.setLocationRelativeTo(null);
       
    }     
        

    }
    
    
    
    

