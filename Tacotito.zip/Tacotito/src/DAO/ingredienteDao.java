
package DAO;
import java.sql.*;
import DAO.tipoIngredienteDao;
import Model.Ingrediente;


public class ingredienteDao extends conexion{
    
    PreparedStatement ps;
    Statement st;
    tipoIngredienteDao tipDao = new tipoIngredienteDao();
    private static ingredienteDao instance ;
    
    public static ingredienteDao getInstance() throws SQLException {
        if ( instance == null ) {
            instance = new ingredienteDao();
        }
        instance.conectar();
        return instance;
    }
    
    public void guardarIngrediente(Ingrediente i) throws SQLException {
        if ( i.getId() == 0 ) {
            nuevoIngrediente(i);
      
        }
   
    }
   
    private void nuevoIngrediente(Ingrediente i) throws SQLException {
        String sql;
        sql = "INSERT INTO ingredientes (idTipoIngrediente, nombre, precio) VALUES (?, ?, ?)"; //"INSERT INTO ingredientes(idTipoIngrediente, nombre, precio) VALUES(?,?,?);";        
        ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
        ps.setInt(1, i.getTipoIngrediente().getIdTipoIngrediente());
        ps.setString(2, i.getNombreIngrediente());
        ps.setInt(3, i.getPrecio());
        ps.executeUpdate();
        ResultSet rs = ps.getGeneratedKeys();
        if ( rs.next() ) {
            i.setId(rs.getLong(1));
        }
    }

/*public List<Ingrediente> listarIngredientes() {
        List<Ingrediente> salidaIngrediente = new ArrayList();
        Ingrediente i = null;
        try {
            st = con.createStatement();
           ResultSet rs = st.executeQuery("SELECT  FROM ingredientes");
            while (rs.next()) {
                i = new Ingrediente(rs.getString(3),rs.getInt(4));
                i.setId(rs.getLong(1));
                salidaIngrediente.add(i);
            }
        } catch (SQLException e) {
        }
        return salidaIngrediente;
    }*/


}