
package Model;

import java.util.Objects;

public class Ingrediente {
    protected long id; 
    protected String nombreIngrediente;
    protected int precio;
    protected TipoIngrediente tipoIngrediente;

    public Ingrediente() {
    }

    
    /*Constructures*/
     public Ingrediente(String nombreIngrediente, int precio, TipoIngrediente tipoIngrediente) {
        this.nombreIngrediente = nombreIngrediente;
        this.precio = precio;
        this.tipoIngrediente = tipoIngrediente;
    }

    public Ingrediente(String nombreIngrediente, int precio) {
        this.nombreIngrediente = nombreIngrediente;
        this.precio = precio;
    }
    
    /*geters and setters*/
    public String getNombreIngrediente() {
        return nombreIngrediente;
    }

    public void setNombreIngrediente(String nombreIngrediente) {
        this.nombreIngrediente = nombreIngrediente;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) {
        this.precio = precio;
    }

    public TipoIngrediente getTipoIngrediente() {
        return tipoIngrediente;
    }

    public void setTipoIngrediente(TipoIngrediente tipoIngrediente) {
        this.tipoIngrediente = tipoIngrediente;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 37 * hash + (int) (this.id ^ (this.id >>> 32));
        hash = 37 * hash + Objects.hashCode(this.nombreIngrediente);
        hash = 37 * hash + this.precio;
        hash = 37 * hash + Objects.hashCode(this.tipoIngrediente);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Ingrediente other = (Ingrediente) obj;
        if (this.id != other.id) {
            return false;
        }
        if (this.precio != other.precio) {
            return false;
        }
        if (!Objects.equals(this.nombreIngrediente, other.nombreIngrediente)) {
            return false;
        }
        return Objects.equals(this.tipoIngrediente, other.tipoIngrediente);
    }
       
    /*toString*/

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Ingrediente{");
        sb.append("id=").append(id);
        sb.append(", nombreIngrediente=").append(nombreIngrediente);
        sb.append(", precio=").append(precio);
        sb.append(", tipoIngrediente=").append(tipoIngrediente);
        sb.append('}');
        return sb.toString();
    }
   
}
